globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/yQOMyYxU65olaUT0XPgmv/_buildManifest.js",
    "static/yQOMyYxU65olaUT0XPgmv/_ssgManifest.js",
    "static/yQOMyYxU65olaUT0XPgmv/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/0zdr-jag8pcfx.js",
    "static/chunks/2gcx7vebc6tr6.js",
    "static/chunks/turbopack-3e3x0c2mimgci.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
