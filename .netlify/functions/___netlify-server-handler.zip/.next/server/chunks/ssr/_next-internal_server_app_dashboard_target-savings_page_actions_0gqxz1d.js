module.exports=[12819,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_dashboard_target-savings_page_actions_0gqxz1d.js.map