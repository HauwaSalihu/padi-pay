module.exports=[44783,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_dashboard_settings_adminSettings_page_actions_16ttq4x.js.map